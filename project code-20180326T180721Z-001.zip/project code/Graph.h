//
//  Graph.hpp Updated
//  22C Labs
//
//  Created by Ambro Quach on 3/1/18.
//  Copyright © 2018 Ambro Quach. All rights reserved.
//

#ifndef Graph_hpp
#define Graph_hpp

#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <vector>
#include "List.h"
//#include "User.h"
//#include "BST.h"
//#include "HashTable.h"

using namespace std;

class Graph {
public:
    
    /**Constructors and Destructors*/
    
    Graph(int n);
    //initializes an empty graph to have n vertices
    ~Graph();
    //destroys the graph
    
    /*** Access Functions ***/
    
    int getNumEdges() const;
    //returns the number of edges in the graph
    
    int getNumVertices() const;
    //returns the number of vertices in the graph
    
    bool isEmpty() const;
    //returns whether the graph is empty (no vertices)
    
    int getDistance(int v) const;
    //Pre: v <= vertices
    //Returns the value of the distance[v]
    
    int getParent(int v) const;
    //Pre: v <= vertices
    //Returns the value of the parent[v]
    
    char getColor(int v) const;
    //Pre: v <= vertices
    //Returns the value of color[v]
    
    /*** Manipulation Procedures ***/
    
    void addEdge(int u, int v);
    //inserts vertex v into the adjacency list of vertex u (i.e. inserts v into the list at index u)
    //and inserts u into v.
    void removeEdge(int u, int v);
    //removes vertex v into the adjacency list of vertex u (i.e. removes v into the list at index u)
    //and removes u into v.
    
    void removeVertex(int v);
    //removes all edges that v connects to, then removes vertex v and its adjacency list
    /*** Additional Operations ***/
    
    void printGraph(ostream& out);
    //Prints the adjacency list of each vertex in the graph,
    //vertex: <space separated list of adjacent vertices>
    //Prints to the console or to an output file given the ostream parameter
    
    void printBFS(ostream& out);
    //Prints the current values in the parallel vectors after executing BFS
    //Prints to the console or to an output file given the ostream parameter
    //First prints the heading:
    //v <tab> c <tab> p <tab> d <tab>
    //Then, prints out this information for each vertex in the graph
    //Note that this function is intended purely to help you debug your code
    
    void printDFS(ostream& out);
    //Prints the current values in the parallel vectors after executing DFS
    //Prints to the console or to an output file given the ostream parameter
    //First prints the heading:
    //v <tab> c <tab> d <tab> f <tab> p <tab>
    //Then, prints out this information for each vertex in the graph
    //Note that this function is intended purely to help you debug your code

    
    void BFS(int source);
    //Performs breath first search on this Graph give a source vertex
    //pre: at least one vertex must exist
    //pre: source is a vertex in the graph
    
    void DFS();
    //Performs depth first search on this Graph give a source vertex
    //pre: at least one vertex must exist
    
    void visitVertex(int i);
    //Helper function of depth first search
    
    int getDTime(int v) const;
    //Returns the discovery time of a vertex in DFS
    
    int getFTime(int v) const;
    //Returns the finish time of a vertex in DFS
    
    void printPath(int source, int destination, ostream& out);
    //Prints the path from the source to the destination vertex
    //Prints to the console or to an output file given the ostream parameter
    
//    void printUser (User user, ostream& out) const
//    {
//        
//    }
    
private:
    int vertices, edges, time; //number of edges and vertices
    vector<List<int>> adj;
    vector<char> color;
    vector<int> distance;
    vector<int> parent;
    vector<int> discoverTime;
    vector<int> finishTime;
    
};
#endif /* Graph_hpp */

//Graph::Graph(int n) : vertices(n), edges(0), adj(n, List<int>()), color(n, 'W'), distance(n, -1), parent(n, 0) {}
Graph::Graph(int n)
{
    vertices = n;
    edges = 0;
    time = 0;
    // operator[] cannot be used to insert new values into the vector
    // the vector must already contain elements for this operator to work
    for (int i = 0; i <= vertices; i++)
    {
        adj.push_back(List<int>());
        color.push_back('W');
        distance.push_back(-1);
        parent.push_back(0);
        discoverTime.push_back(0);
        finishTime.push_back(0);
    }
}
//initializes an empty graph to have n vertices

Graph::~Graph()
{
    adj.clear();
    color.clear();
    distance.clear();
    parent.clear();
    discoverTime.clear();
    finishTime.clear();
}
//destroys the graph

/*** Access Functions ***/

int Graph::getNumEdges() const
{
    return edges;
}
//returns the number of edges in the graph

int Graph::getNumVertices() const
{
    return vertices;
}
//returns the number of vertices in the graph

bool Graph::isEmpty() const
{
    return adj.empty();     // return true if vector is empty, false if not
}
//returns whether the graph is empty (no vertices)

int Graph::getDistance(int v) const
{
    assert (v <= vertices);
    return distance[v];
}
//Pre: v <= vertices
//Returns the value of the distance[v]

int Graph::getParent(int v) const
{
    assert (v <= vertices);
    return parent[v];
}
//Pre: v <= vertices
//Returns the value of the parent[v]

char Graph::getColor(int v) const
{
    assert (v <= vertices);
    return color[v];
}
//Pre: v <= vertices
//Returns the value of color[v]

int Graph::getDTime(int v) const
{
    assert (v <= vertices);
    return discoverTime[v];
}

int Graph::getFTime(int v) const
{
    assert (v <= vertices);
    return finishTime[v];
}
/*** Manipulation Procedures ***/

void Graph::addEdge(int u, int v)
{
    // undirected graph -- bi-directional edge between 2 vertices
    // linearSearch to prevent duplicate edges
    
    //    if (adj[u].isEmpty() || adj[u].linearSearch(v) == -1)    // empty checking is prioritized before searching
    // insertNode() will take care of sppecial cases as commented out above
	if (adj[u].isEmpty() || adj[u].binarySearch(v) == -1)
	{
		if (u == v)
			adj[u].insertNode(v);
		else
		{
			adj[u].insertNode(v);
			adj[v].insertNode(u);
		}
		edges++;
	}
}
//inserts vertex v into the adjacency list of vertex u (i.e. inserts v into the list at index u)
//and inserts u into v.

void Graph::removeEdge(int u, int v)
{
    //    assert(!adj[u].isEmpty());
    //    if (adj[u].linearSearch(v) != -1)   // element is in the list
    // removeNode() will take care of sppecial cases as commented out above
    
    assert(!isEmpty());
    if (u == v)
        adj[u].removeNode(v);
    else
    {
        adj[u].removeNode(v);
        adj[v].removeNode(u);
    }
    edges--;
}
//removes vertex v into the adjacency list of vertex u (i.e. removes v into the list at index u)
//and removes u into v.

void Graph::removeVertex(int v)
{
    assert(!isEmpty());
    assert(!adj[v].isEmpty());
    
    for(int i = 0; i <= vertices; i++)
    {
        if (adj[i].isEmpty() || adj[i].binarySearch(v) == -1)
            continue;
        adj[i].removeNode(v);
        edges--;
    }
    adj[v].freeList();
    
    //    adj.erase(adj.begin()+5);
    //    adj.erase(remove(adj.begin(), adj.end(), v), adj.end());
    //    vertices--;
}
//removes all edges that v connects to, then removes vertex v and its adjacency list

/*** Additional Operations ***/

void Graph::printGraph(ostream& out)
{
    for (int i = 0; i < vertices; i++)
    {
        out << i + 1 << ": ";
        adj[i].printList(out);
    }
    out << endl;
}
//Prints the adjacency list of each vertex in the graph,
//vertex: <space separated list of adjacent vertices>
//Prints to the console or to an output file given the ostream parameter

void Graph::printBFS(ostream& out)
{
    out << "Breadth First Search\n";
    out << "v\tc\tp\td\n";
    for (int i = 0; i < (int) adj.size() - 1; i++)
    {
        out << i << "\t"
        << color[i] << "\t"
        << parent[i] << "\t"
        << distance[i];
        out << endl;
    }
}
//Prints the current values in the parallel vectors after executing BFS
//Prints to the console or to an output file given the ostream parameter
//First prints the heading:
//v <tab> c <tab> p <tab> d <tab>
//Then, prints out this information for each vertex in the graph
//Note that this function is intended purely to help you debug your code

void Graph::BFS(int source)
{
    assert(!isEmpty());
    assert(source <= vertices);
    
    for (int i = 0; i <= vertices; i++)
    {
        color[i] = 'W';
        distance[i] = -1;
        parent[i] = -1;
    }
    
    List<int> queue;
    color[source] = 'G';
    distance[source] = 0;
    queue.insertLast(source);
    
    while(!queue.isEmpty())
    {
        int i = queue.getFirst();
        queue.removeFirst();
        adj[i].startIterator();
        while (!adj[i].offEnd())     // Iterator's not off end;
        {
            int j = adj[i].getIterator();
            if (color[j] == 'W')
            {
                color[j] = 'G';
                distance[j] = distance[i] + 1;
                parent[j] = i;
                queue.insertLast(j);
            }
            adj[i].advanceIterator();
        }
        color[i] = 'B';
    }
}
//Performs breath first search on this Graph give a source vertex
//pre: at least one vertex must exist
//pre: source is a vertex in the graph

void Graph::printDFS(ostream& out)
{
    out << "Depth First Search\n";
    out << "v\tc\td\tf\tp\n";
    for (int i = 0; i < (int) adj.size(); i++)
    {
        out << i << "\t"
        << color[i] << "\t"
        << discoverTime[i] << "\t"
        << finishTime[i] << "\t";
        parent[i] == 78 ? out << (char)parent[i] << "\t" : out << parent[i] << "\t";
        out << endl;
    }
}

void Graph::DFS()
{
    assert(!isEmpty());
    
    for (int i = 0; i <= vertices; i++)
    {
        color[i] = 'W';
        parent[i] = 78;     // ASCII value for 'N'
        discoverTime[i] = -1;
        finishTime[i] = -1;
    }
    time = 0;
    for (int i = 0; i <= vertices; i++)
    {
        if (color[i] == 'W')
            visitVertex(i);
    }
}

void Graph::visitVertex(int i)
{
    color[i] = 'G';
    discoverTime[i] = ++time;
    adj[i].startIterator();
    
    while (!adj[i].offEnd())     // iterator's not off end;
    {
        int j = adj[i].getIterator();
        if (color[j] == 'W')
        {
            parent[j] = i;
            visitVertex(j);
        }
        adj[i].advanceIterator();
    }
    
    color[i] = 'B';
    finishTime[i] = ++time;
}


void Graph::printPath(int source, int destination, ostream& out)
{
    if (destination == source)
    {
        out << source << " ";
    }
    else if (parent[destination] == 0)
    {
        out << "No path from vertex " << source << " to " << destination << " exists";
        distance[destination] = -1;
    }
    else
    {
        printPath(source, parent[destination], out);
        out << destination << " ";
    }
}
//Prints the path from the source to the destination vertex
//Prints to the console or to an output file given the ostream parameter
