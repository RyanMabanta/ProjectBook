/*
cis22c Winter 2018
course project
Team 1
FilmBook

TEAM 1:
Alex Haas
Christian Acosta
John Kim
Ryan Mabanta
Thanh Quach
*/

#include <iostream>
#include <fstream>		//fstream
#include <sstream>		//stringstream
#include "BST.h"
#include "Graph.h"
#include "HashGenre.h"
#include "HashLogin.h"
#include "HashUser.h"

using namespace std;	// may not need...

/* GLOBAL FUNCTION DECLARATIONS */
void clearScreen();
//pre???
//post???

int countLines(fstream& iFile);
//pre???
//post???

void displayMainMenu(User* user);
//pre???
//post???

/* MAIN */

int main()
{
	/*
		1:
		READ FROM INPUT FILE OR NOT:
	*/

	clearScreen();		// for formatting reasons.

	string inputFile;

	cout << "Please enter the name of the database file that loads the network: ";
	getline(std::cin, inputFile);

	// open input file:
	fstream iFile;
	iFile.open(inputFile, ios::in);

	while (!iFile.good())
	{
		std::cout << "\n\n\"" << inputFile << "\" could not be opened. Try again or hit enter to exit:" << endl;
		getline(std::cin, inputFile);
		iFile.open(inputFile, ios::in);

		if (inputFile == "") exit(0);
	}

	// count lines before creating local objects. function resets iFile.
	int SIZE = countLines(iFile);

	/*
		MAIN LOCAL OBJECTS:
		individual namespaces used so as to keep functions collision from happening.
	*/
	HL::HashLogin Logins_(SIZE);		// login only.
	HU::HashUser HashUsers(SIZE);		// contains everything minus password.
	HG::HashGenre Genres_(SIZE);
	/* is loaded after hash tables are loaded. */
	Graph theGraph(SIZE);
	User* localUser;		// used throughout. don't delete.

	// created alongside hash tables and used to create Graph:
	vector<string> userVector;
	vector<BST<string>*> friendVector;

	// assists with finding users by genre type:
	vector<string> genreTypes;

	// used many times. don't delete. seriously... please... really. thanks.
	string tempStr;


	/*
		2:
		LOAD HASHTABLES AND VECTORS USED TO CREATE GRAPH:
	*/

	while (getline(iFile, tempStr))
	{
		stringstream tempStream;	// localized stream.
		List<string> tempList;		// holds delimited values from data file string.
		BST<string> friends;		// used in loop to load friends into each User.
		User* tempUser;

		tempStream.str(tempStr);
		tempStr = "";

		// divides string from data file into delimited values:
		while (getline(tempStream, tempStr, ',')) tempList.insertLast(tempStr);

		if (tempList.getLength() < 6) continue;		// bad line. error checking.

		string name = tempList.getFirst();
		tempList.removeFirst();
		string password = tempList.getFirst();
		tempList.removeFirst();
		string genre = tempList.getFirst();
		tempList.removeFirst();
		string country = tempList.getFirst();
		tempList.removeFirst();
		string movie = tempList.getFirst();
		tempList.removeFirst();
		string favorite = tempList.getFirst();
		tempList.removeFirst();

		while (!tempList.isEmpty())		// handles friends:
		{
			friends.insert(tempList.getFirst());
			tempList.removeFirst();
		}

		tempUser = new User(name, password);
		Logins_.insert(tempUser);		// Logins_ insert.

		tempUser = new User(name, genre, country, movie, favorite, friends);
		HashUsers.insert(tempUser);		// HashUsers insert.

		tempUser = new User(name," ", genre);
		Genres_.insert(tempUser);		// Genres_ insert.

		userVector.push_back(name);
		friendVector.push_back(new BST<string>(friends));

		// processing genre types:
		if (genreTypes.size() == 0) genreTypes.push_back(genre);
		else
		{
			bool foundGenre = false;

			for (unsigned i = 0; i < genreTypes.size(); i++)
			{
				if (genreTypes[i] == genre) foundGenre = true;
			}

			if (!foundGenre) genreTypes.push_back(genre);
		}
	}// end line by line while loop.

	iFile.close();		// close filestream.

	/*
		3:
		CREATE GRAPH USING VECTORS:
	*/
	for (unsigned i = 0; i < friendVector.size(); i++)
	{
		int value = -1;
		
		stringstream tempStream;	// localized stream.

		friendVector[i]->inOrderPrint(tempStream);

		while (getline(tempStream, tempStr, '\n'))
		{			
			for (unsigned j = 0; j < userVector.size(); j++)
			{
				if (userVector[j] == tempStr)
				{
					value = j;
					theGraph.addEdge(i, value);
				}
			}
			// for debugging:
			// theGraph.printGraph(cout);
		}
	}

	std::cout << "\nUsers have been added to the database...\n" << endl;

	/*
		4:
		LOG USER IN OR NOT:
	*/
	string userName;
	string password;

	std::cout << "username: ";
	getline(std::cin, userName);
	std::cout << "password: ";
	getline(std::cin, password);

	localUser = new User(userName, password);

	while (Logins_.search(localUser) == -1)
	{
		std::cout << "\nUser could not be found.\nTry again or hit enter twice to exit:" << endl;
		std::cout << "username: ";
		getline(std::cin, userName);
		std::cout << "password: ";
		getline(std::cin, password);

		if (userName == "" && password == "") exit(0);

		//delete localUser;////////////////////////////////////////////////////////////////////////////////////////
		localUser = new User(userName, password);
	}

	localUser = HashUsers.getUser(localUser);		// now stores logged-in user.

	std::cout << "\nThanks for logging in " << localUser->getName() << ". Press enter to continue to the main menu..." << endl;

	/*
		5:
		FINISHES LOADING GRAPH NOW THAT USES LOGIN CONFIRMED:
	*/
	getline(std::cin, tempStr);
	
	/*
		6:
		MAIN MENU LOOP UNTIL EXIT:
	*/
	while (tempStr[0] - '0' != 7)		// Main Menu while loop:
	{
		clearScreen();
		displayMainMenu(localUser);

		std::cout << "\n\nYour selection: ";
		getline(std::cin, tempStr);

		while (tempStr[0] - '0' > 7 || tempStr[0] - '0' < 1)		// error checking on user input.
		{
			std::cout << "The only entries allowed are the single digits '1' through '7'." << endl;
			std::cout << "Your selection: ";
			getline(std::cin, tempStr);
		}

		if (tempStr[0] - '0' == 1)
		{
			clearScreen();
			std::cout << "Viewing profile for ";
			localUser->printData();
			std::cout << "\nPress enter to continue to Main Menu" << endl;
			getline(std::cin, tempStr);
		}
		else if (tempStr[0] - '0' == 2)
		{
			stringstream localStream;
			string localString;
			vector<string> thefriends;

			clearScreen();

			if (localUser->getFriends()->isEmpty())
			{
				std::cout << "You do not have any friends!\nTry to add some by using options in the Main Menu.\n" << endl;
				std::cout << "\nPress enter to continue to the Main Menu..." << endl;
				getline(std::cin, tempStr);
			}
			else
			{
				std::cout << "Your friends:\n" << endl;
				localUser->printFriends(localStream);


				while (getline(localStream, localString, '\n'))
				{
					thefriends.push_back(localString);
				}

				for (unsigned i = 0; i < thefriends.size(); i++)
				{
					std::cout << i + 1 << ": " << thefriends[i] << endl;
				}

				std::cout << "\nPlease enter the number of the friend you would\n" <<
					"like to view or enter anything else and hit enter\n" <<
					"to return to main menu...\n" << endl;
				getline(std::cin, tempStr);

				if (tempStr != "" && (unsigned)stoi(tempStr) <= thefriends.size() && (unsigned)stoi(tempStr) > 0)
				{
					User* tempuser = new User(thefriends[stoi(tempStr) - 1]);

					User* frienduser = HashUsers.getUser(tempuser);

					clearScreen();

					std::cout << "Your friend's profile:\n" << endl;

					frienduser->printData();

					std::cout << "\nPress enter to continue to the Main Menu." << endl;
					getline(std::cin, tempStr);
				}
			}// end else
		}
		else if (tempStr[0] - '0' == 3)
		{
			clearScreen();

			if (!localUser->getFriends()->isEmpty())
			{
				std::cout << "\nWhich friend do you want to remove?\n" << endl;
				getline(std::cin, tempStr);

				if (!localUser->getFriends()->search(tempStr))
				{
					std::cout << "\nThat friend does not exist in your friend list.\n" << endl;
				}
				else
				{
					clearScreen();

					localUser->getFriends()->remove(tempStr);		// User removed from logged-in-user's friend's list.
					
					// removes from vectors and then from graph:
					for (unsigned i = 0; i < userVector.size(); i++)
					{
						if (userVector[i] == localUser->getName())
						{
							friendVector[i]->remove(tempStr);

							for (unsigned j = 0; j < userVector.size(); j++)
							{
								if (userVector[j] == tempStr) friendVector[j]->remove(localUser->getName());

								theGraph.removeEdge(i, j);
								theGraph.BFS(i);

								break;
							}
						}

						break;
					}

					std::cout << "\n" << tempStr << " has been removed from your friend's list.\n" << endl;
				}
			}
			else
			{
				std::cout << "You have no friends to remove.\n" << endl;
			}

			std::cout << "Press enter to continue to the Main Menu." << endl;
			getline(std::cin, tempStr);
		}
		else if (tempStr[0] - '0' == 4)
		{
			clearScreen();
			
			std::cout << "SEARCH BY NAME:\n" << endl;

			std::cout << "Enter the name you want to search for: ";
			getline(std::cin, tempStr);

			User* tempUser = new User(tempStr);

			if (HashUsers.search(tempUser) != -1)
			{
				std::cout << tempStr << " found.\n" << endl;

				std::cout << tempStr << "'s profile:\n" << endl;

				tempUser = HashUsers.getUser(tempUser);

				tempUser->printData();

				std::cout << "\n\nWould you like to add this person as your friend?" <<
					"\nOPTIONS:\n1: YES\n2: NO\n" << endl;

				getline(std::cin, tempStr);

				if (stoi(tempStr) == 1)
				{
					localUser->getFriends()->insert(tempUser->getName());

					std::cout << "\n" << tempUser->getName() << " is now your friend!" << endl;
				}
				else std::cout << "\nThat response was not recognized.\nThe only allowed entries are '1' or '2'.\n" << endl;
			}
			else std::cout << tempStr << " could not be found in the network.\n" << endl;

			std::cout << "\nPress enter to continue to the Main Menu." << endl;
			getline(std::cin, tempStr);
		}
		else if (tempStr[0] - '0' == 5)
		{
			clearScreen();

			std::cout << "SEARCH BY GENRE:\n" << endl;

			std::cout << "Choose from the available genres:\n" << endl;
			
			for (unsigned i = 0; i < genreTypes.size(); i++) std::cout << i + 1 << ": " << genreTypes[i] << endl;

			std::cout << endl;

			getline(std::cin, tempStr);

			if (stoi(tempStr) > 0 && (unsigned) stoi(tempStr) <= genreTypes.size())
			{
				std::cout << "\nUsers with a similar genre to the one chosen:\n" << endl;

				stringstream localstream;
				Genres_.printBucket(localstream, Genres_.hash(genreTypes[stoi(tempStr) - 1]));
				std::cout << localstream.str() << endl;
			}
			else
			{
				std::cout << "\nOnly " << 1 << " through " << genreTypes.size() << " is allowed input.\n" << endl;
			}

			std::cout << "\nPress enter to continue to the Main Menu." << endl;
			getline(std::cin, tempStr);
		}
		else if (tempStr[0] - '0' == 6)
		{
			/*
				LOAD GRAPH WITH CURRENT USER INFO:
			*/
			int mmyself = -1;

			for (unsigned i = 0; i < userVector.size(); i++)
			{
				if (userVector[i] == localUser->getName())
				{
					mmyself = i;
					theGraph.BFS(i);
					break;
				}
			}

			List<int> localList;

			// going into parent...
			for (unsigned i = 0; i < userVector.size(); i++)		// change to size of graph's parent vector...
			{
				if (theGraph.getDistance(i) > 1) localList.insertLast(i);
			}

			stringstream localStream;
			localList.printList(localStream);

			List<int> intList;
			List<string> recList;

			while (getline(localStream, tempStr, ' '))
			{
				if (tempStr.length() > 0 && tempStr != "\n")
				{
					std::cout << stoi(tempStr) - 1 << endl;
					intList.insertLast(stoi(tempStr) - 1);
				}
			}

			while (!intList.isEmpty())
			{
				int temp = intList.getFirst();
				intList.removeFirst();

				string recommendedname = userVector[temp];

				User* newUser = new User(recommendedname, "", localUser->getGenre());

				// provides error checking so that existing friend is not recommended:
				if (HashUsers.search(newUser) < -1 && !localUser->getFriends()->search(recommendedname))
				{
					if (recList.getLength() < 3) recList.insertLast(recommendedname);
				}
			}

			clearScreen();

			std::cout << "There are " << recList.getLength() << " recommended users based upon your common friends and genre.\n" << endl;

			if (recList.getLength() > 0)
			{
				recList.reversePrint(std::cout);

				std::cout << "Enter the number of the person you'd like to add or enter to go back to the Main Menu: ";
				getline(std::cin, tempStr);

				if (tempStr != "" && stoi(tempStr) <= recList.getLength() && stoi(tempStr) > 0)
				{
					for (int i = 0; i < stoi(tempStr) - 1; i++)////////
					{
						recList.removeFirst();
					}

					localUser->getFriends()->insert(recList.getFirst());		// localUser taken care of.
					HashUsers.getUser(localUser)->getFriends()->insert(recList.getFirst());		// takes care of Hashtable.


					// adds to vectors that support Graph and Graph itself:
					for (unsigned i = 0; i < userVector.size(); i++)
					{
						if (userVector[i] == recList.getFirst())
						{
							for (unsigned j = 0; j < userVector.size(); j++)
							{
								if (userVector[j] == localUser->getName())
								{
									// vectors first;
									friendVector[i]->insert(userVector[j]);
									friendVector[j]->insert(userVector[i]);

									// then graph:
									theGraph.addEdge(i, j);
									theGraph.BFS(j);

									break;
								}
							}

							break;
						}
					}

					std::cout << "\n" << recList.getFirst() << " is in your friends list!\n" << endl;

					std::cout << "\nPress enter to continue to the Main Menu." << endl;
					getline(std::cin, tempStr);
				}
				// do nothing...
			}
			else
			{
				std::cout << "Use the Main Menu to find friends via Name or Genre (easiest method):\n" << endl;
				std::cout << "\nPress enter to continue to the Main Menu." << endl;
				getline(std::cin, tempStr);
			}		
		}// end if 6
		else if (tempStr[0] - '0' == 7)		// program to close after saving database to user input:
		{
			clearScreen();

			string fileName;

			cout << "PREPARING TO LEAVE FILM-BOOK:\n\n";

			cout << "Please enter the name of the file that\n" <<
				"the current database will be saved to:\n" << endl;
			cout << "Name: ";
			getline(std::cin, fileName);

			while (fileName == "\n")
			{
				cout << "\nPlease enter something...\n" << endl;
				cout << "Name: ";
				getline(std::cin, fileName);
			}

			ofstream outFile;
			outFile.open(fileName, ios::out);

			iFile.open(inputFile, ios::in);
			while (getline(iFile, tempStr))
			{
				stringstream tempStream;	// localized stream.
				stringstream tempStream2;		// localized stream.
				List<string> tempList;		// holds delimited values from data file string.
				BST<string> friends;		// used in loop to load friends into each User.

				tempStream.str(tempStr);
				tempStr = "";

				// divides string from data file into delimited values:
				while (getline(tempStream, tempStr, ',')) tempList.insertLast(tempStr);

				if (tempList.getLength() < 6) continue;		// bad line. error checking.

				string name = tempList.getFirst();
				tempList.removeFirst();
				string password = tempList.getFirst();
				tempList.removeFirst();
				string genre = tempList.getFirst();
				tempList.removeFirst();
				string country = tempList.getFirst();
				tempList.removeFirst();
				string movie = tempList.getFirst();
				tempList.removeFirst();
				string favorite = tempList.getFirst();
				tempList.removeFirst();

				outFile << name << ',' << password << ',' << genre << ',' << country << ',' << movie << ',' << favorite;

				// handles logged-in-user's friends:
				if (name == localUser->getName())
				{
					localUser->getFriends()->inOrderPrint(tempStream2);
				}
				else
				{
					while (!tempList.isEmpty())
					{
						tempStream2 << tempList.getFirst() << "\n";
						tempList.removeFirst();
					}
				}

				// insert friends:
				while (getline(tempStream2, tempStr, '\n'))
				{
					outFile << ',' << tempStr;
				}

				outFile << "\n";
			}// end line by line while.

			outFile.close();

			tempStr = "7";
		
			clearScreen();

			std::cout << "\n\ndatabase is saved to " << fileName << ".\n\nThank you for using Film-book, a Team 1 production!" << endl;

			cout << "Press any key to quit." << endl;
			std::cin.ignore();
		}// End Main Menu ifs.

	}// End Main Menu while loop.

	return 0;
}// END MAIN

/* GLOBAL FUNCTION DEFINITIONS */

void clearScreen()
{
	for (int i = 0; i < 4; i++) std::cout << "\n\n\n\n\n\n\n\n\n\n" << endl;
}

int countLines(fstream& iFile)		// resets iFile before returning to main.
{
	int count = 0;
	string temp;

	while (getline(iFile, temp)) count++;

	iFile.clear();
	iFile.seekg(0, ios::beg);

	return count;
}

void displayMainMenu(User* user)
{
	std::cout << "\tWELCOME TO FILM-BOOK\n" << endl;
	std::cout << "You are logged in as: " << user->getName() << endl;
	std::cout << "\n1. VIEW YOURSELF\n2. VIEW YOUR FRIENDS\n3. REMOVE A FRIEND\n4. SEARCH NETWORK BY NAME\n5. SEARCH NETWORK BY GENRE\n6. RECOMMEND SOME FRIENDS FOR ME!\n7. QUIT FILM-BOOK" << endl;
}

// End filmbook.cpp