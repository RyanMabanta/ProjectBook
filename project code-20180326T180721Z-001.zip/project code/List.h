/*
cis22c Winter 2018
course project
Team 1
FilmBook
*/

#ifndef LIST_H_
#define LIST_H_

#include <cstddef> //for NULL
#include <cassert> //for assert()
#include <sstream>

//using namespace std;

template <class listdata>
class List {

private:
	struct Node {
		listdata data;
		Node* next;
		Node* prev;

		Node(listdata newData) {
			data = newData;
			next = NULL;
			prev = NULL;
		}
	};

	Node* first;
	Node* last;
	Node* iterator;
	int length;

	void freeList(Node* first) const;
	//Private helper function for the public freeList();
	//Recursively deletes the all the nodes in the ist

	void reversePrint(ostream& out, Node* node, int& number) const;	// lab 4
	//Helper function for the public reversePrint() function.
	//Recursively prints the data in a List in reverse.

	bool isSorted(Node* node) const;
	//Helper function for the public isSorted() function.
	//Recursively determines whether a list is sorted in ascending order.

	int binarySearch(int low, int high, listdata data) const;
	//Recursively search the list by dividing the search space in half
	//Returns the index of the element, if it is found in the List
	//Returns -1 if the element is not in the List
	//Post: The iterator location has not been changed

public:

	/**Constructors and Destructors*/

	List();
	//Default constructor; initializes and empty list
	//Postcondition: List is initialized. All variables are empty.

	List(const List &obj);
	//Copy constructor: creates a copy of a list, empty or not.

	~List();
	//Destructor. Frees memory allocated to the list
	//Postcondition: List object is destroyed and any dynamic memory is freed.

	/**Accessors*/


	void freeList();
	//Deletes all value in the list
	//Post: isEmpty() = true, first and last node = NULL

	listdata getFirst() const;
	//Returns the first data in the list
	//Precondition: List must contain at least one Node.

	listdata getLast() const;
	//Returns the last data in the list
	//Precondition: List must contain at least one Node.

	bool isEmpty() const;
	//Determines whether a list is empty and returns false or true.

	int getLength() const;
	//Returns the size of the list

	listdata getIterator() const;
	// returns iterator's data.
	//Precondition: iterator must exist.
	//postcondition: data is returned to code calling function.

	bool offEnd() const;
	// returns if iterator is NULL or not.

	bool operator==(List &obj) const;
	// compares two lists to see if they're different.
	//Postcondition: returns true if both lists have same nodes/listdata. Returns false otherwise.

	bool isSorted() const;	// lab4
	//Wrapper function that calls the isSorted helper function to determine whether
	//a list is sorted in ascending order.

	int getIndex() const;	// lab4
	//Indicates the index of the Node where the iterator is currently pointing
	//Nodes are numbered starting at 1 through the size of the list
	//Pre: !offEnd()

	int linearSearch(listdata data) const;	// lab 4
	//Searchs the list, element by element, from the start of the List to the end of the List
	//Returns the index of the element, if it is found in the List
	//Does not call the indexing functions in the implementation
	//Returns -1 if the element is not in the List
	//Pre: length != 0
	//Post: The iterator location has not been changed

	int binarySearch(listdata data) const;	// lab 4
	//Returns the index where data is located in the List
	//Calls the private helper function binarySearch to perform the search
	//Pre: length != 0
	//Pre: List is sorted (must test on a sorted list)
	//Post: The iterator location has not been changed

	/**Manipulation Procedures*/

	void removeNode(listdata data);
	//Removes the value stored in a specific node in the list
	//Precondition: The list cannot be empty
	//Postcondition: Desired element of the list will be removed

	void insertNode(listdata data);
	//Inserts a new data at a specific node of the list
	//If the list is empty, the new data becomes both first and last
	//Postcondition: New element will be inserted to desired location of the list
	//Postcondition: List is organized in ascending order

	void removeFirst();
	//Removes the value stored in first node in the list
	//Precondition: List must contain at least one Node.
	//Postcondition: The first Node in List will be removed. The once-second Node will now become the first Node.
	//If only one node in List, List will be empty.

	void removeLast();
	//Removes the value stored in the last node in the list
	//Precondition: List must contain at least one Node.
	//Postcondition: Last Node in List is removed. The once-second-to-last Node will now point to NULL.
	//If only one node in List, List will be empty.

	void insertFirst(listdata data);
	//Inserts a new data at the beginning of the list
	//If the list is empty, the new data becomes both first and last
	//Postcondition: int data is inserted into a new Node and becomes the head Node in this List.

	void insertLast(listdata data);
	//Inserts a new data at the end of the list
	//If the list is empty, the new data becomes both first and last
	//Postcondition: int data is inserted into a new Node and becomes the last Node in this List.

	void startIterator();
	// sets iterator to start of list.
	//Precondition: first exists.
	//Postcondition: iterator = first.

	void removeIterator();
	// removes Node pointed to by iterator.
	//Precondition: iterator exists.
	//Postcondition: iterator now points to NULL. iterator's previous data has been deleted.

	void insertIterator(listdata data);
	// inserts Node after iterator.
	//Precondition: iterator exists.
	//Postcondition: length++

	void advanceIterator();
	// moves iterator forward one.
	//Precondition: iterator exists
	//Postcondition: iterator equals data or NULL.

	void reverseIterator();
	// moves iterator backward one.
	//Precondition: iterator exists.
	//Postcondition: iterator equals data or NULL.

	void advanceToIndex(int index);	// lab4
	//Moves the iterator to the node whose index number is specified in the parameter
	//Nodes are numbered starting at 1 through the size of the List
	//Pre: size != 0
	//Pre: index <= size

	/**Additional List Operations*/

	void printList(ostream& out) const;		// Adjusted for Lab8
	//Prints to the console the value of each data in the list sequentially
	//and separated by a blank space
	//Prints nothing if the list is empty
	//Prints a empty newline character if it's empty..

	void printNumberedList() const;
	// printList but with numbers and newlines.

	void reversePrint(ostream& out) const;	// lab 4
	//Wrapper function that calls the reverse helper function to print a list in reverse
	//prints nothing if the List is empty
};

/* List.cpp pasted below */
/**Constructors and Destructors*/

template <class listdata>
List<listdata>::List() : first(NULL), last(NULL), iterator(NULL), length(0) {}

template <class listdata>
List<listdata>::List(const List &obj)
{
	iterator = NULL;
	length = 0;

	if (obj.length == 0)
		first = last = NULL;
	else
	{
		Node* tempNode = new Node(obj.getFirst());
		first = last = tempNode;
		length++;

		Node* objNode = obj.first->next;

		while (objNode)
		{
			// insertLast increments length:
			this->insertLast(objNode->data);
			objNode = objNode->next;
		}
	}
}

template <class listdata>
List<listdata>::~List()
{
	while (first)
	{
		last = first;
		first = first->next;
		delete last;
	}
}

/**Accessors*/

template <class listdata>
listdata List<listdata>::getFirst() const
{
	assert(first);

	return first->data;
}

template <class listdata>
listdata List<listdata>::getLast() const
{
	assert(last);

	return last->data;
}

template <class listdata>
bool List<listdata>::isEmpty() const
{
	if (first)
		return false;
	else
		return true;
}

template <class listdata>
int List<listdata>::getLength() const
{
	return length;
}

template <class listdata>
listdata List<listdata>::getIterator() const
{
	assert(iterator);

	return iterator->data;
}

template <class listdata>
bool List<listdata>::offEnd() const
{
	if (iterator)
		return false;
	else
		return true;
}

template <class listdata>
bool List<listdata>::operator==(List &obj) const
{
	if (length != obj.length)
		return false;
	
	Node* tempNode = first;
	Node* objNode = obj.first;

	while (tempNode)
	{
		if (tempNode->data == objNode->data)
		{
			tempNode = tempNode->next;
			objNode = objNode->next;
		}
		else
			return false;
	}

	return true;
}

template <class listdata>	// lab4
bool List<listdata>::isSorted() const
{
	return isSorted(first);
}

template <class listdata>	// private member function	// lab 4
bool List<listdata>::isSorted(Node* node) const
{
	if (!node->next)
		return true;

	if (node->next->data >= node->data)
		return isSorted(node->next);
	else
		return false;
}

template <class listdata>	// lab 4
int List<listdata>::getIndex() const
{
	assert(iterator);

	Node* tempNode = first;
	int index = 1;

	while (tempNode != iterator)
	{
		tempNode = tempNode->next;
		index++;
	}

	return index;
}

template <class listdata>	// lab 4
int List<listdata>::linearSearch(listdata data) const
{
	assert(length != 0);
	
	int index = 1;
	Node* tempNode = first;

	while (tempNode)
	{
		if (tempNode->data->getGenre() == data->getGenre() && tempNode->data->getName() == data->getName()) return (index + 2) * -1;
		else if (tempNode->data->getName() == data->getName()) return index;		// LAME...
		else
		{
			tempNode = tempNode->next;
			index++;
		}
	}

	return -1;
}

template <class listdata>	// lab 4
int List<listdata>::binarySearch(listdata data) const
{
	assert(length != 0);
	assert(isSorted(first));

	return binarySearch(1, length, data);
}

template <class listdata>	// private member function.	// lab4
int List<listdata>::binarySearch(int low, int high, listdata data) const
{
	if (high < low)						// end case: data not found:
		return -1;

	Node* tempNode = first;	// iterator.
	int mid = low + (high - low) / 2;	// determine mid.

	for (int i = 0; i < mid - 1; i++)	// advance to mid.
		tempNode = tempNode->next;

	if (tempNode->data == data)			// found it.
		return mid;
	else if (data < tempNode->data)		// maybe less than:
		return binarySearch(low, (mid - 1), data);
	else								// maybe more than:
		return binarySearch((mid + 1), high, data);
}

/**Manipulation Procedures*/

template <class listdata>
void List<listdata>::freeList(Node* first) const
{
	if (!first)
		return;

	freeList(first->next);
	delete first;
	first = NULL;
}

template <class listdata>
void List<listdata>::freeList()
{
	freeList(first);
	first = last = NULL;
	length = 0;
}

template <class listdata>
void List<listdata>::removeNode(listdata data)
{
	assert(length != 0);
	if (data == first->data)
		removeFirst();
	else if (data == last->data)
		removeLast();
	else
	{
		Node* nodePtr = first;
		while (nodePtr && nodePtr->data < data) // to make unsuccessful searches faster
		{
			nodePtr = nodePtr->next;
		}

		if (nodePtr && nodePtr->data == data) // to make sure to only delete the data nodePtr points to that matches data input
		{
			nodePtr->prev->next = nodePtr->next;
			nodePtr->next->prev = nodePtr->prev;
			delete nodePtr;
			length--;
		}
	}
}

template <class listdata>
void List<listdata>::insertNode(listdata data)
{
	if (length == 0)
		insertLast(data);
	else if (length == 1)
		data < getFirst() ? insertFirst(data) : insertLast(data);
	else
	{
		Node *nodePtr = first;
		while (nodePtr->next && nodePtr->data < data)   // Skip all nodes whose value is less than data.
		{
			nodePtr = nodePtr->next;
		}
		if (!nodePtr->next && data >= nodePtr->data)
			insertLast(data);
		else if (!nodePtr->prev && data <= nodePtr->data)
			insertFirst(data);
		else
		{
			Node *newNode = new Node(data);
			newNode->prev = nodePtr->prev;
			newNode->next = nodePtr;
			newNode->prev->next = newNode;
			nodePtr->prev = newNode;
			length++;
		}
	}
}

template <class listdata>
void List<listdata>::removeFirst()
{
	assert(first);

	// handle iterator:
	if (iterator == first)
		iterator = NULL;

	if (first == last)
	{
		delete first;
		first = last = NULL;
	}
	else
	{
		Node* tempNode = first;

		first = first->next;
		first->prev = NULL;

		delete tempNode;
	}

	length--;
}

template <class listdata>
void List<listdata>::removeLast()
{
	assert(last);

	// handle iterator:
	if (iterator == last)
		iterator = NULL;

	if (first == last)
	{
		delete last;
		first = last = NULL;
	}
	else
	{
		Node* tempNode = last;

		last = last->prev;
		last->next = NULL;

		delete tempNode;
	}

	length--;
}

template <class listdata>
void List<listdata>::insertFirst(listdata data)
{
	Node* tempNode = new Node(data);

	if (!first)
		last = first = tempNode;
	else
	{
		tempNode->next = first;
		first->prev = tempNode;
		first = tempNode;
	}

	length++;
}

template <class listdata>
void List<listdata>::insertLast(listdata data)
{
	Node* tempNode = new Node(data);

	if (!last) last = first = tempNode;
	else
	{
		tempNode->prev = last;
		last->next = tempNode;
		last = tempNode;
	}

	length++;
}

template <class listdata>
void List<listdata>::startIterator()
{
	assert(first);

	iterator = first;
}

template <class listdata>
void List<listdata>::removeIterator()
{
	assert(iterator);

	if (iterator == first)
		removeFirst();
	else if (iterator == last)
		removeLast();
	else
	{
		iterator->prev->next = iterator->next;
		iterator->next->prev = iterator->prev;
		delete iterator;
		iterator = NULL;
		length--;
	}
}

template <class listdata>
void List<listdata>::insertIterator(listdata data)
{
	assert(iterator);

	Node* tempNode;

	if (iterator == last)
		insertLast(data);
	else
	{
		tempNode = new Node(data);
		iterator->next->prev = tempNode;
		tempNode->next = iterator->next;
		tempNode->prev = iterator;
		iterator->next = tempNode;
		length++;
	}
}

template <class listdata>
void List<listdata>::advanceIterator()
{
	assert(iterator);

	iterator = iterator->next;
}

template <class listdata>
void List<listdata>::reverseIterator()
{
	assert(iterator);

	iterator = iterator->prev;
}

template <class listdata>	// lab4
void List<listdata>::advanceToIndex(int index)
{
	assert(length != 0);
	assert(index <= length);

	startIterator();

	for (int i = 1; i < index; i++)
		advanceIterator();
}

/**Additional List Operations*/

template <class listdata>
void List<listdata>::printList(ostream& out) const		// Adjusted for Lab8
{
	Node* temp = first; //create a temporary iterator
	while (temp) {
		out << temp->data + 1 << " ";// + 1

		temp = temp->next;


	}
	out << endl;
}


template <class listdata>
void List<listdata>::printNumberedList() const
{
	Node* tempNode = first;
	int count = 0;

	while (tempNode)
	{
		cout << ++count << ". " << tempNode->data << endl;

		tempNode = tempNode->next;
	}

	cout << endl;
}

template <class listdata>	// private member function
void List<listdata>::reversePrint(ostream& out, Node* node, int& number) const
{
	if (!node)
		return;

	out << number++ << ": " << node->data << "\n";

	reversePrint(out, node->next, number);

}

template <class listdata>
void List<listdata>::reversePrint(ostream& out) const
{
	int number = 1;

	reversePrint(out, first, number);

	// covers if empty:
	cout << endl;
}
#endif /* LIST_H_ */
// END List.h
