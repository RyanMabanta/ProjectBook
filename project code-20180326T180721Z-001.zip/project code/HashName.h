/*
cis22c Winter 2018
course project
Team 1
FilmBook
*/

#ifndef HASHNAME_H_
#define HASHNAME_H_

#include <string>
#include <cassert>		//assert()
#include "List.h"
#include "User.h"

using namespace std;

namespace HN {

	class HashName
	{
	public:
		/**CONSTRUCTORS/DESTRUCTOR*/

		HashName();
		HashName(int SIZE);
		~HashName() {}

		/**Access Functions*/
		int search(User* u, string genre_) const;

		User* getUser(User* u) const;

		int search(User* u) const;

		int hash(string key) const;
		//returns the hash value for the given key
		//the hash value is the sum of
		//of the ASCII values of each char in the key

		int countBucket(int index) const;
		//counts the number of Users at this index
		//returns the count
		//pre: 0<= index < SIZE

		friend ostream& operator<<(ostream &stream, const User& obj);//////////////////////////////////////////////////////////////////////////////////////////////////////
		//pre???
		//post???

		/**Manipulation Procedures*/

		void insert(User* b);
		//inserts a new book into the table
		//calls the hash function on the key to determine
		//the correct bucket

		void remove(User* b);
		//removes b from the table
		//calls the hash function on the key to determine
		//the correct bucket
		//pre: b is in the table

		/**Additional Functions*/

		void printBucket(ostream& out, int index) const;
		//Prints all the Users at index
		//pre: 0<= index < SIZE

		void printTable(ostream& out) const;
		//Prints the first User at each index
		//along with a count of the total Users
		//at each index by calling count_bucket
		//as a helper function

	private:
		int SIZE;
		List<User*>* Table;
	};

	/**CONSTRUCTORS/DESTRUCTOR*/

	HashName::HashName() : SIZE(0), Table() {}

	HashName::HashName(int size_)
	{
		SIZE = size_ * 2;

		Table = new List<User*>[SIZE];
	}

	/**Access Functions*/

	User* HashName::getUser(User* u) const
	{
		int temp1 = Table[hash(u->getName())].linearSearch(u);

		Table[hash(u->getName())].startIterator();

		for(int i = 0; i < --temp1; i++) Table[hash(u->getName())].advanceIterator();

		if(Table[hash(u->getName())].getIterator()) return Table[hash(u->getName())].getIterator();
		else return NULL;
	}

	int HashName::search(User* u) const
	{
		int index = hash(u->getName());

		if (Table[index].isEmpty())		// prevent assertion failed from linearSearch()
			return -1;
		else if (Table[index].linearSearch(u) > -1)
		{
			return index;
		}
		else if (Table[index].linearSearch(u) < -1)
		{
			return (Table[index].linearSearch(u));
		}

		return -1;
	}

	int HashName::hash(string key) const
	{
		int count = 0;

		for (unsigned i = 0; i < key.length(); i++) count += (int)key[i];

		return count % SIZE;
	}

	int HashName::countBucket(int index) const
	{
		assert(0 <= index && index < SIZE);

		return Table[index].getLength();
	}

	ostream& operator<<(ostream &stream, const User& obj)
	{
		stream << obj.getName() << " ";
		return stream;
	}

	/**Manipulation Procedures*/

	void HashName::insert(User* u)
	{
		//cout << "HashNameinsert" << endl;
		Table[hash(u->getName())].insertLast(u);
	}

	void HashName::remove(User* u)//??????????????????????????????????????????????????????? NOT TESTED
	{
		assert(search(u) != -1);

		int index1 = hash(u->getName());

		Table[index1].advanceToIndex(Table[index1].linearSearch(u));	// gets to right node.
		Table[index1].removeIterator();
	}

	/**Additional Functions*/

	void HashName::printBucket(ostream& out, int index) const
	{
		assert(index >= 0 && index < SIZE);
		Table[index].printList(out);
	}

	void HashName::printTable(ostream& out) const
	{
		for (int index = 0; index < SIZE; index++)
		{
			if (Table[index].isEmpty())
				continue;
			else
			{
				out << "Group " << index + 1 << "\n"
					<< Table[index].getFirst()
					<< "+ " << countBucket(index) - 1 << " more similar User(s)"
					<< "\n\n";
			}
		}
	}

}

#endif /* HASHNAME_H_ */
// End HashName.h