/*
cis22c Winter 2018
course project
Team 1
FilmBook
*/

#ifndef BST_H_
#define BST_H_

#include <cstddef>
#include <string>
#include <assert.h>

using namespace std;

template <class bstdata>
	class BST
	{
	private:
		struct Node
		{
			bstdata data;
			Node* left;
			Node* right;

			Node(bstdata newdata)
			{
				data = newdata;
				left = NULL;
				right = NULL;
			}
		};

		Node* root;

		/**Private helper functions*/

		bstdata minimum(Node* root) const;
		//recursive helper function to minimum
		//returns the minimum value in the tree

		bstdata maximum(Node* root) const;
		//recursive helper function to maximum
		//returns the maximum value in the tree

		bool searchNode(Node* root, bstdata data) const;

		void copyNode(Node* copy);
		//recursive helper function to the copy constructor

		void insertNode(Node* root, bstdata data);
		//private helper function for insert
		//recursively inserts a value into the BST

		void inOrderPrint(ostream& out, Node* root) const;
		//private helper function for inOrderPrint
		//recursively prints tree values in order from smallest to largest

		void freeNode(Node* root);
		//private helper function for the destructor
		//recursively frees the memory in the BST

		Node* removeNode(Node* root, bstdata data);
		//recursive helper function to remove
		//removes data from the tree

		void getSize(Node* root, int& size) const;
		//recursive helper function to the size function
		//calculates the size of the tree
		//stores the result in size

	public:

		/**constructors and destructor*/

		BST();
		//Instantiates a new BST

		BST(const BST& obj);
		//???
		//???

		~BST();
		//deallocates the tree memory

		/**access functions*/

		bstdata minimum() const;
		//returns the minimum value in the BST
		//pre: !empty()

		bstdata maximum() const;
		//returns the maximum value in the BST
		//pre: !empty()


		//BST<bstdata>

		bool search(bstdata data) const;

		bool isEmpty() const;
		//determines whether the BST is empty

		int getSize() const;
		//returns the size of the tree

		/**manipulation procedures*/

		void insert(bstdata data);
		//inserts new data into the BST

		void remove(bstdata data);
		//removes the specified value from the tree
		//pre: data is located in the tree
		//pre: !isEmpty()

		/**additional functions*/

		void inOrderPrint(ostream& out) const;
		//calls the inOrderPrint function to print out the values
		//stored in the BST
	};

	/**Private helper functions*/

	template <class bstdata>
	bstdata BST<bstdata>::minimum(Node* root) const
	{
		if (root->left) return minimum(root->left);
		else return root->data;
	}

	template <class bstdata>
	bstdata BST<bstdata>::maximum(Node* root) const
	{
		if (root->right) return maximum(root->right);
		else return root->data;
	}

	template <class bstdata>
	bool BST<bstdata>::searchNode(Node* root, bstdata data) const
	{
		if (root->data == data) return true;

		if (data < root->data)
		{
			if (root->left) return searchNode(root->left, data);
		}
		else if (data > root->data)
		{
			if (root->right) return searchNode(root->right, data);
		}

		return false;
	}
	//recursive helper function to search
	//returns whether the value is found in the tree

	template <class bstdata>
	void BST<bstdata>::copyNode(Node* copy)	// Pre-order
	{
		//cout << "start of copynode" << endl;
	//	if(copy) cout << copy->data << endl;

		if (!copy) return;

		insert(copy->data);
		copyNode(copy->left);
		copyNode(copy->right);
	}

	template <class bstdata>
	void BST<bstdata>::insertNode(Node* root, bstdata data)
	{
		//cout << "inside insertnode helper " << data << endl;

		if (root->data == data)	return;		// no duplicates.
			
		if (data < root->data)
		{
			//cout << "data is less than root data" << endl;
			if (!root->left)
				root->left = new Node(data);
			else
				insertNode(root->left, data);
		}
		else if (!root->right)
		{
			//cout << " right didn't exist but is about to" << endl;
			root->right = new Node(data);

		}
		else
			insertNode(root->right, data);

		//cout << "end of insertNode helper " << endl;
	}

	template <class bstdata>
	void BST<bstdata>::inOrderPrint(ostream& out, Node* root) const
	{
		if (!root) return;

		inOrderPrint(out, root->left);
		out << root->data << "\n";
		inOrderPrint(out, root->right);
	}

	template <class bstdata>
	void BST<bstdata>::freeNode(Node* root)
	{
		if (!root) return;

		freeNode(root->left);
		freeNode(root->right);

		delete root;
	}

	template <class bstdata>
	typename BST<bstdata>::Node* BST<bstdata>::removeNode(Node* root, bstdata data)
	{
		if (!root) return NULL;

		if (data < root->data) root->left = removeNode(root->left, data);
		if (data > root->data) root->right = removeNode(root->right, data);

		if (root->data == data)
		{
			Node* temp = root;

			if (root->left == NULL && root->right == NULL)	// is leaf:
			{
				delete root;
				root = NULL;
			}
			else if (root->left && !root->right)			// single child is left:
			{
				root = root->left;
				delete temp;	
			}
			else if (root->right && !root->left)			// single child is right:
			{
				root = root->right;
				delete temp;
			}
			else											// two kiddos:
			{
				root->data = minimum(root->right);
				root->right = removeNode(root->right, minimum(root->right));
			}
		}// end if.

		return root;
	}

	template <class bstdata>
	void BST<bstdata>::getSize(Node* root, int& size) const	// Post-order
	{
		if (!root) return;

		getSize(root->left, size);
		getSize(root->right, size);

		size++;
	}

	///* all below are public: *///

	/** constructors and destructor */

	template <class bstdata>
	BST<bstdata>::BST() : root(NULL) {}

	template <class bstdata>
	BST<bstdata>::BST(const BST &bst)
	{
		//tally = 0;

		if (bst.isEmpty()) root = NULL;
		else copyNode(bst.root);
	}

	template <class bstdata>
	BST<bstdata>::~BST()
	{
		if (root)
		{
			freeNode(root);
			root = NULL;
		}
	}

	/**access functions*/

	template <class bstdata>
	bstdata BST<bstdata>::minimum() const
	{
		assert(root);

		return minimum(root);
	}

	template <class bstdata>
	bstdata BST<bstdata>::maximum() const
	{
		assert(root);

		return maximum(root);
	}

	template <class bstdata>
	bool BST<bstdata>::isEmpty() const
	{
		if (getSize() < 1) return true;
		else return false;
	}

	template <class bstdata>
	int BST<bstdata>::getSize() const	// Post-order
	{
		if (!root) return -1;

		int size = 0;
		getSize(root, size);
		return size;
	}

	template <class bstdata>
	bool BST<bstdata>::search(bstdata data) const
	{
		assert(root);

		return searchNode(root, data);
	}

	/**manipulation procedures*/

	template <class bstdata>
	void BST<bstdata>::insert(bstdata data)
	{
		if (!root) root = new Node(data);
		else insertNode(root, data);
	}

	template <class bstdata>
	void BST<bstdata>::remove(bstdata data)
	{
		assert(root);
		assert(searchNode(root, data));

		this->root = removeNode(root, data);

	}

	/**additional functions*/

	template <class bstdata>
	void BST<bstdata>::inOrderPrint(ostream& out) const
	{
		inOrderPrint(out, root);
	}
#endif /* LIST_H_ */
// End BST.h