/*
cis22c Winter 2018
course project
Team 1
FilmBook
*/

#ifndef USER_H_
#define USER_H_

#include "List.h"
#include "BST.h"

#include <iostream>

using namespace std;

class User
{
private:
	string name;
	string password;
	string genre;
	string country;
	string movie;
	string favorite;
	BST<string>* myFriends;

public:
	/* CONSTRUCTOR/DESTRUCTOR */
	User();
	User(string name_);		///////
	User(string name_, string password_);		// HashLogin's Users.
	User(string name_, string genre_, string country_, string movie_, string favorite_, BST<string>& friends_);		// HashName's Users.
	User(string name_, string nothing, string genre_);

	~User();

	/* ACCESSORS */
	string getName() const;
	//pre???
	//post??

	string getPassword() const;
	//pre???
	//post???

	string getGenre() const;
	//pre???
	//post???

	string getCountry() const;
	//pre???
	//post???

	string getMovie() const;
	//pre???
	//post???

	string getFavorite() const;
	//pre???
	//post???

	void printFriends(ostream& out) const;
	//pre???
	//post???

	void printData() const;
	//pre???
	//post???

	bool operator==(User* ptr) const;
	//pre???
	//post???

	BST<string>* getFriends();

	void changeFriends(BST<string>* friends_);

};

/* CONSTRUCTOR/DESTRUCTOR */

User::User() : name(""), password(""), genre(""), country(""), movie(""), favorite(""), myFriends() {}

User::User(string name_) : name(name_), password(""), genre(""), country(""), favorite(""), myFriends() {}

User::User(string name_, string password_) : name(name_), password(password_), genre("nogenre"), country(""), favorite(""), myFriends() {}		// HashLogin...

User::User(string name_, string genre_, string country_, string movie_, string favorite_, BST<string>& friends_)		// HashUsers...
{
	name = name_;
	password = "";
	genre = genre_;
	country = country_;
	movie = movie_;
	favorite = favorite_;
	myFriends = new BST<string>(friends_);
}

User::User(string name_, string nothing, string genre_)		// HashGenre...
{
	name = name_;
	password = "";
	genre = genre_;
	country = "";
	movie = "";
	favorite = "";
	myFriends = NULL;
}

User::~User()
{
	if (myFriends) delete myFriends;
}

/* ACCESSORS */

void User::changeFriends(BST<string>* friends_)
{

}

BST<string>* User::getFriends()
{
	return myFriends;
}

string User::getName() const
{
	return name;
}

string User::getPassword() const
{
	return password;
}

string User::getGenre() const
{
	return genre;
}

string User::getCountry() const
{
	return country;
}

string User::getMovie() const
{
	return movie;
}

string User::getFavorite() const
{
	return favorite;
}

void User::printFriends(ostream& out) const
{
	stringstream tempStream;
	//stringstream tempStream2;
	string tempString;

	myFriends->inOrderPrint(tempStream);

	while (getline(tempStream, tempString, '\n'))
	{
		out << tempString << "\n";
	}
}

void User::printData() const
{
	stringstream tempStream;

	cout << name << "\n" << endl;
	cout << "Genre: " << genre << endl;
	cout << "Country of origin: " << country << endl;
	cout << "Biggest movie in sales: " << movie << endl;
	cout << "Favorite actor/actress: " << favorite << endl;
	//myFriends->inOrderPrint(tempStream);
	//cout << tempStream.str() << endl;
}

bool User::operator==(User* ptr) const////////////////////////////////////////////////////////////////////////////
{
	cout << "here" << endl;
	if (this->getName() == ptr->getName()) return true;
	else return false;
}

#endif /* USER_H_ */
//End User.h